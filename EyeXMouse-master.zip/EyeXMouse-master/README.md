EyeXMouse
=========

Mouse cursor control for the Tobii EyeX

Very crude program for controlling the mouse cursor using the Tobii EyeX development kit.

Requires Tobii EyeX Controller and Software

Useful for any Mouse Cursor games e.g. http://www.gamebase.info/magazine/read/top-10-eye-gaze-games_294.html 

Works well in The Grid 2. Set input to 'Pointer > All options > Dwell pointer over cell'


**Program DOES NOT exit gracefully (requires ctrl+alt+del) and has no options**


Purchase a Tobii EyeX development kit for £72.99 (inc. delivery) from http://www.tobii.com/en/eye-experience/buy/order-eyex



##Credit

https://github.com/gigertron/EyeTracker

http://developer.tobii.com/community/forums/topic/gaming-and-desktop-mouse-control-with-the-rex


## License
Code is under the [GPLv3 license] (https://github.com/mikethrussell/EyeXMouse/blob/master/LICENSE.txt).